def init(motionProxy):
	motionProxy.setChainStiffness ("LArm",1.0)
	angle=[0.0,0.0,0.0,0.0,0.0,1.0]
	motionProxy.gotoChainAngles ("LArm",angle,10.0,1)
def movez(z,motionProxy):
	gpos=motionProxy.getPosition("LArm",0) 
	print "asd"
	print "gpos : ",gpos
	tpos=list(gpos)
	fpos=list(gpos)
	tpos[2]=tpos[2]+z
	print "tpos :",tpos
	count=0
	while tpos!=fpos and count<1:
		motionProxy.gotoPosition ("LArm",0,tpos,7,2.0,1)
		fpos=motionProxy.getPosition("LArm",0)
		print "fpos : ",fpos
		count=count+1
def final(motionProxy):
	motionProxy.setChainStiffness ("LArm",1.0)
	glarm=motionProxy.getChainAngles ("LArm")
	tlarm=[-1.5094980001449585, 1.2072160243988037, 0.010696038603782654, -1.2102841138839722, 0.006094038486480713, 0.07493533194065094 ]
	motionProxy.gotoChainAngles ("LArm",tlarm,5.0,1)
	motionProxy.gotoChainAngles ("LArm",glarm,5.0,1)

def rest(motionProxy):
	motionProxy.setChainStiffness ("LArm",1.0)
	angle=[1.3,0.0,0.0,0.0,0.0,1.0]
	motionProxy.gotoChainAngles ("LArm",angle,5.0,1)
