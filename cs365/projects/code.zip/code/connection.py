import os
import sys
import time
aldir_env = os.environ.get("AL_DIR")

if aldir_env is None:
  print "The environnement variable AL_DIR is not set, aborting..."
  exit(1)

aldir = os.path.abspath(aldir_env)
alpath = os.path.join(aldir,"extern/python/aldebaran")
sys.path.append(alpath)
try:
  import naoqi
  from naoqi import ALBroker
  from naoqi import ALModule
  from naoqi import ALProxy
  from naoqi import ALBehavior
  from naoqi import ALProxy
except ImportError, err:
  print "Unable to import naoqi module: " + str(err)
  exit(1)
IP = "nao.local"

PORT = 9559

if (IP == "" ):
  print "IP address not defined, aborting"
  print "Please define it in " + __file__
  exit(1)

# ======================= PRINT  ==========================
print "CurrentConfig: Using IP: " + str(IP) + " and port: "  + str(PORT)

####
# Create motion proxy
print "Creating motion proxy"
try:
  motionProxy = ALProxy("ALMotion",IP,PORT)
except Exception,e:
  print "Error when creating motion proxy:"
  print str(e)
  exit(1)
####
# Create proxy on ALVideoDevice

print "Creating ALVideoDevice proxy"

try:
  camProxy = ALProxy("ALVideoDevice", IP, PORT)
except Exception,e:
  print "Error when creating vision proxy:"
  print str(e)
  exit(1)
