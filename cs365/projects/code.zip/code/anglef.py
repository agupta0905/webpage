import math
from math import *
import motion
l1=0.089
l2=0.143
def ik(x,y,motionProxy):
	a1=motionProxy.getAngle("LShoulderRoll")
	a2=motionProxy.getAngle("LElbowRoll")
	a2=-a2
	ye=l1*sin(a1)-l2*sin((a2-a1))
	xe=l1*cos(a1)+l2*cos((a2-a1))
	x=x+xe
	y=y+ye
	d=sqrt(x**(2)+y**(2))
	if d>l1+l2:
		print "not reachable"
		exit(1)
	ca=(l1**(2)+d**(2)-l2**(2))/(2*l1*d)
	a=math.acos(ca)
	if y>0:
		b=pi-math.atan(x/y)
	else :
		b=math.atan(x/(-y))
	a1=a+b-(pi/2)
	cc=(l1**(2)+l2**(2)-d**(2))/(2*l1*l2)
	c=math.acos(cc)
	a2=c-pi
	mystruct = [a1,a2]
	return mystruct
def grasppose(motionProxy):
	a1=motionProxy.getAngle("LShoulderRoll")
	a2=motionProxy.getAngle("LElbowRoll")
	a2=-a2
	x=0.01*cos(a2-a1)
	y=-0.01*sin(a2-a1)
	mystruct=[x,y]
	return mystruct
	
