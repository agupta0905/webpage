from opencv.cv import *
from opencv.highgui import *
import cv
import Image
def on_mouse( event, x, y, flags, param ):
        if event == CV_EVENT_MOUSEMOVE :
                print cvGet2D(hsv_frame,y,x)               
hsv_frame = cvCreateImage((320,240), IPL_DEPTH_8U, 3)
thresholded = cvCreateImage((320,240), IPL_DEPTH_8U, 1)
thresholded2 = cvCreateImage((320,240), IPL_DEPTH_8U, 1)
thresholdeds = cvCreateImage((320,240), IPL_DEPTH_8U, 1)
hsv_min = cvScalar(0, 0, 170, 0)
hsv_max = cvScalar(35,145, 256, 0)
hsv_min2= cvScalar(170, 50, 170, 0)
hsv_max2= cvScalar(256, 180,256, 0)
cvNamedWindow("window")
cvNamedWindow("hsvframe")
cvNamedWindow("thresholded")
cvNamedWindow("thresholdeds")
cvSetMouseCallback("hsvframe",on_mouse,None);
def objdet(camProxy,clientName):
	count=0
	r=0.0
	n=0
	cx=0.0
	cy=0.0	 
	while count<10:	
    		img = camProxy.getImageRemote(clientName);
    		imgw= img[0]
    		imgh= img[1]
    		imga= img[6]

  # Create a PIL Image from our pixel array.
    		im = Image.fromstring("RGB", (imgw, imgh), imga)
    		num=str(count)
    		name="camimage"+num+".png"
    		im.save("camImage.png", "PNG")
    		frame= cvLoadImage('camImage.png', 1)
    		storage = cvCreateMemStorage(0)
    		cvCvtColor(frame, hsv_frame, CV_BGR2HSV)
    		name="hsvimage"+num+".png"
    		cvInRangeS(hsv_frame, hsv_min, hsv_max, thresholded)
    		name="thresholded"+num+".png"
    		cvInRangeS(hsv_frame, hsv_min2, hsv_max2, thresholded2)
    		cvSmooth(thresholded, thresholdeds, CV_GAUSSIAN, 9, 9)
    		maxRadius =rdet['radius']
		y=rdet['centery']
		x=rdet['centerx']
		x1=int(x)
        	x2=int(y)
       		maxRadiusi=int(maxRadius)
    		found = True
    		if found:
     			print "ball detected at position:",x, ",", y, " with radius:", maxRadius
     			cvCircle(frame,(x1,x2),maxRadiusi,cv.CV_RGB(200,100,10),1,8,0)
  			cvCircle(frame,(x1,x2),1,CV_RGB(200,100,10),3,8,0)
     			r=r+maxRadius
     			cx=cx+x
     			cy=cy+y
     			n=n+1
		else:
     			print "no ball" 
     			n=1
    		cvShowImage("hsvframe",hsv_frame) 
    		cvShowImage("thresholded",thresholded)
    		cvShowImage("thresholdeds",thresholdeds)
    		cvShowImage("window",frame)
   		cv.WaitKey(5)
	
   		
    #/** Access the image buffer (6th field) and assign it to the opencv image
    #* container. */

    #/** Tells to ALVideoDevice that it can give back the image buffer to the
    #* driver. Optional after a getImageRemote but MANDATORY after a getImageLocal.*/
    #c.camProxy.releaseImage(clientName);

    #/** Display the iplImage on screen.*/

  #/** Cleanup.*/
    		count=count+1
    	cvDestroyWindow("window")
	cvDestroyWindow("hsvframe")
	cvDestroyWindow("thresholded")
	cvDestroyWindow("thresholdeds")
	r=r/n
   	cx=cx/n
   	cy=cy/n
  	mystruct = {'radius':r,'centerx':cx,'centery':cy}		
  	return mystruct  	                
def radiusdet(frame):
	d=0
	cy=0
	cx=0
	for y in range(240):
		count=0
		tex=0
		for x in range(315):
			value=cvGet2D(frame,y,x)[0]
			value1=cvGet2D(frame,y,x+1)[0]
			value2=cvGet2D(frame,y,x+2)[0]
			value3=cvGet2D(frame,y,x+3)[0]
			value4=cvGet2D(frame,y,x+4)[0]
			value5=cvGet2D(frame,y,x+5)[0]
			if(value>100):
				if(x<5):
					if(value1>100 or value2>100):
						count=count+1
						if(count>25):
							tex=x	
				else:
					nvalue1=cvGet2D(frame,y,x-1)[0]
					nvalue2=cvGet2D(frame,y,x-2)[0]
					#nvalue3=cvGet2D(frame,y,x-3)[0]
					#nvalue4=cvGet2D(frame,y,x-4)[0]
					#nvalue5=cvGet2D(frame,y,x-5)[0]
					if(value1>100 or value2>100 or nvalue1>100 or nvalue2>100):
						count=count+1
						if(count>25):
							tex=x
			elif(count<25 and count>0 and value1==0 and value2==0 and value3==0):
				count=0
			elif(count>25 and value1==0 and value2==0 and value3==0):
				break
			elif(count!=0):
				count=count+1
				if(count>25):
					tex=x
		if(count>d):
			d=count
			cy=y
			cx=tex-d/2
	mystruct = {'radius':d/2,'centerx':cx,'centery':cy}
	return mystruct
