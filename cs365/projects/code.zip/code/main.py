from connection import * 
import vision as v
from vision_definitions import*
import train
import anglef
import pose
pose.init(motionProxy)
setup=1
if setup==0:
	exit(1)
resolution = kQVGA
colorSpace = kRGBColorSpace
fps = 15
clientName = camProxy.subscribe("python_GVM", resolution, colorSpace, fps)
result=v.objdet(camProxy,clientName)
camProxy.unsubscribe(clientName)
r=result['radius']
cy=result['centery']
cx=result['centerx']
print "Radius = " ,r,"center y = ",cy,"center x = ",cx
finalcord=train.testontrain(r,cx,cy)
x=float(finalcord[0])
y=float(finalcord[1])
z=float(finalcord[2])
x=(x-12.5)/100
y=(y-9)/100
z=(z-9)/100
joint=["LShoulderRoll","LElbowRoll"]
a1=motionProxy.getAngle("LShoulderRoll")
a2=motionProxy.getAngle("LElbowRoll")
gangle=[a1,a2]
tangle=anglef.ik(x,y,motionProxy)
print " gangle : ",gangle
print "tangle : ",tangle
count=0
while tangle!=gangle and count<1:
	motionProxy.gotoAngles (joint,tangle,2.0,1)
	a1=motionProxy.getAngle("LShoulderRoll")
	a2=motionProxy.getAngle("LElbowRoll")
	gangle=[a1,a2]
	print "gangle " ,gangle
	count=count+1
print "reached"
z=z+0.05
pose.movez(z,motionProxy)
final=anglef.grasppose(motionProxy)
x=final[0]
y=final[1]
joint=["LShoulderRoll","LElbowRoll"]
a1=motionProxy.getAngle("LShoulderRoll")
a2=motionProxy.getAngle("LElbowRoll")
gangle=[a1,a2]
tangle=anglef.ik(x,y,motionProxy)
print " gangle : ",gangle
print "tangle : ",tangle
count=0
while tangle!=gangle and count<1:
	motionProxy.gotoAngles (joint,tangle,1.0,1)
	a1=motionProxy.getAngle("LShoulderRoll")
	a2=motionProxy.getAngle("LElbowRoll")
	gangle=[a1,a2]
	print "gangle " ,gangle
	count=count+1
motionProxy.closeHand("LHand")
z=0.10
pose.movez(z,motionProxy)
pose.final(motionProxy)
motionProxy.openHand("LHand")

