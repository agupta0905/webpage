from numpy import *
import numpy as np
from numpy import linalg
from math import *
q=40*pi/180
def depth(radius):
	# x1=a + (b*R)
	# R=1/r
	# x2=x1 - a
	X=mat('[1 0.0264; 1 0.02638; 1 0.02755; 1 0.02849; 1 0.029412; 1 0.03003; 1 0.03125;1 0.03195;1 0.032471;1 0.03356]')
	xt=np.transpose(X)
	xtx=xt.dot(X)
	xtxi=linalg.inv(np.matrix(xtx))
	xtxixt=xtxi.dot(xt)
	y=mat('[1.532; 2.298; 3.064; 3.83; 4.596; 5.362; 6.128;6.894;7.66;8.426]')
	#y=[(1*20^(-1)); (1*19^(-1)); (1*18^(-1)); (1*17^(-1)); (1*16^(-1))]
	r=xtxixt.dot(y)
	a=r[0][0]
	b=r[1][0]
	R=1/radius
	x1=a+b*R
	return x1
def yaxis(x1,cx):
	# cx=A + (B*y1)
	# A=a/(x1+22.029)
	# B=b/(x1+22.029)
	X=mat('[1 1; 1 2; 1 3; 1 -1; 1 -2; 1 -3; 1 -4;1 -5;1 -6]')
	xt=np.transpose(X)
	xtx=xt.dot(X)
	xtxi=linalg.inv(np.matrix(xtx))
	xtxixt=xtxi.dot(xt)
	y=mat('[104.1; 79.9; 50.0; 149.4; 171; 195.8; 221.9;245.7;267.5]')
	#y=[(1*20^(-1)); (1*19^(-1)); (1*18^(-1)); (1*17^(-1)); (1*16^(-1))]
	r=xtxixt.dot(y)
	A=r[0][0]
	B=r[1][0]
	a=A*(2.298+22.029)
	b=B*(2.298+22.029)
	A=a/(x1+22.029)
	B=b/(x1+22.029)
	y1=(cx-A)/B
	return y1
def zaxis(x1,cy):
	# cy*(x1+22.029)=a + (b*z1) 
	X=mat('[1 1.285; 1 1.928; 1 2.5711; 1 3.214; 1 3.8567; 1 4.4995; 1 5.1423;1 5.7850;1 6.4278;1 7.07666]')
	xt=np.transpose(X)
	xtx=xt.dot(X)
	xtxi=linalg.inv(np.matrix(xtx))
	xtxixt=xtxi.dot(xt)
	y=mat('[4396.4826; 4159.917; 3804.0988; 3395.2867;3069.8625;2698.0135;2348.2938;2024.61;1653.6773;1324.7925]')
	#y=[(1*20^(-1)); (1*19^(-1)); (1*18^(-1)); (1*17^(-1)); (1*16^(-1))]
	r=xtxixt.dot(y)
	a=r[0][0]
	b=r[1][0]
	z1=(cy*(x1+22.029)-a)/b
	return z1
def transform(x1,y1,z1):
	x=x1*cos(q)+z1*sin(q)
	y=y1
	z=z1*cos(q)-x1*sin(q)
	return [x,y,z]
def testontrain(radius,cx,cy):
	x1=depth(radius)
	y1=yaxis(x1,cx)
	z1=zaxis(x1,cy)
	result=transform(x1,y1,z1)
	return result
