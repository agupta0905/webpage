[ data, names ] = loadImageData('box1');
data=im2double(data);
edistance=L2_distance(data,data);
[Y,R,E]=Isomap(edistance,'k',3);