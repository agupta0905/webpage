[data,labels]=loadDigits(2000);
edistance=L2_distance(data,data);
[Y,R,E]=Isomap(edistance,'k',7);
for m=1:9
    ind{m}=find(labels==m);
    Twod{m}=Y.coords{2}(:,ind{m});
end
ind{10}=find(labels==0);
Twod{10}=Y.coords{2}(:,ind{10});
figure;
plot(Twod{1}(1,:),Twod{1}(2,:), 'ro',Twod{7}(1,:),Twod{7}(2,:),'bo');
title('Isomap Plot of 1 and 7');
legend('1','7');
figure;
plot(Twod{4}(1,:),Twod{4}(2,:), 'ro',Twod{9}(1,:),Twod{9}(2,:),'bo');
title('Isomap Plot of 4 and 9');
legend('4','9');
figure;
hold all;
plot(Twod{10}(1,:),Twod{10}(2,:), 'c*',Twod{1}(1,:),Twod{1}(2,:),'mo');
plot(Twod{2}(1,:),Twod{2}(2,:), 'yo',Twod{3}(1,:),Twod{3}(2,:),'ro');
plot(Twod{4}(1,:),Twod{4}(2,:), 'go',Twod{5}(1,:),Twod{5}(2,:),'b*');
plot(Twod{6}(1,:),Twod{6}(2,:), 'ko',Twod{7}(1,:),Twod{7}(2,:),'ks');
plot(Twod{8}(1,:),Twod{8}(2,:), 'kd',Twod{9}(1,:),Twod{9}(2,:),'k*');
title('Isomap of all the digits');
legend('0','1','2','3','4','5','6','7','8','9');
hold off;
for k=1:10
    figure;
    hold all;
    plot(Twod{k}(1,:),Twod{k}(2,:),'b*');
    title('Isomap with figures');
    for m=1:10:151
        col=data(:,ind{k}(m));
        col=reshape(col,28,28);
        col=col';
        x(2)=Y.coords{2}(1,ind{k}(m));
        x(1)=x(2)-250.0;
        y(2)=0.0;
        y(1)=Y.coords{2}(2,ind{k}(m));
        y(2)=y(1)-250.0;
        imagesc(x,y,col);
        colormap(gray);
    end
    hold off;
end    
