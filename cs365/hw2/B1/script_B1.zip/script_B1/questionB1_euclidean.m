[ data, names ] = loadImageData('nao200');
data=im2double(data);
edistance=L2_distance(data,data);
[Y,R,E]=Isomap(edistance,'k',7);