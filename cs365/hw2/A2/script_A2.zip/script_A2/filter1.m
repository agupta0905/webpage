function data1 = filter1(data,values,labels)
m = size(data,2);
n = size(labels,2);
a = [1:n];
k=1;
l = size(values,2);
for i = 1:n
    if (any(labels(1,i)==values)==1)
        a(1,k)=i;
        k=k+1;
    end
x = a(1,1:k-1);
data1 = x;
end