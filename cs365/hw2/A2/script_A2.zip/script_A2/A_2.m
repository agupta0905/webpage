%part-1 using euclidean distance

N = 2000;
type = 'test';
[data,labels] = loadDigits(N,type);
data1 = filter1(data,[1],labels);
data2 = filter1(data,[2],labels);
data3 = filter1(data,[3],labels);
data4 = filter1(data,[4],labels);
data5 = filter1(data,[5],labels);
data6 = filter1(data,[6],labels);
data7 = filter1(data,[7],labels);
data8 = filter1(data,[8],labels);
data9 = filter1(data,[9],labels);

% Part-2 using tangent distance
dist_mat = tangent_d(data(:,:),data(:,:),1);
options.dims = [1:10];
[Y,R,E] = Isomap(dist_mat,'k',7,options);

h=figure;
hold on
p = plot(Y.coords{2}(1,data1),Y.coords{2}(2,data1),'o');
q = plot(Y.coords{2}(1,data7),Y.coords{2}(2,data7),'+');
set(p,'Color','red');
set(q,'Color','black');
title('2-D Isomap model for the 2000 samples of the MNIST training set using tangent-distance');

xlabel('X');
ylabel('Y');
hleg1 = legend('1','7');

%fil = sprintf('1_7_tan_%d.jpg',i);
%saveas(h,fil);
hold off;


h=figure;
hold on;
r = plot(Y.coords{2}(1,data4),Y.coords{2}(2,data4),'o');
s = plot(Y.coords{2}(1,data9),Y.coords{2}(2,data9),'+');
set(r,'Color','red');
set(s,'Color','black');
title('2-D Isomap model for the 2000 samples of the MNIST training set using tangent-distance');
xlabel('X');
ylabel('Y');
hleg1 = legend('4','9');
%fil = sprintf('4_9_tan_%d.jpg',i);
%saveas(h,fil);
hold off;

h=figure;
hold on;
r1 = plot(Y.coords{2}(1,data1),Y.coords{2}(2,data1),'o');
r2 = plot(Y.coords{2}(1,data2),Y.coords{2}(2,data2),'o');
r3 = plot(Y.coords{2}(1,data3),Y.coords{2}(2,data3),'o');
r4 = plot(Y.coords{2}(1,data4),Y.coords{2}(2,data4),'o');
r5 = plot(Y.coords{2}(1,data5),Y.coords{2}(2,data5),'o');
r6 = plot(Y.coords{2}(1,data6),Y.coords{2}(2,data6),'o');
r7 = plot(Y.coords{2}(1,data7),Y.coords{2}(2,data7),'o');
r8 = plot(Y.coords{2}(1,data8),Y.coords{2}(2,data8),'o');
r9 = plot(Y.coords{2}(1,data9),Y.coords{2}(2,data9),'+');
set(r1,'Color','y');
set(r2,'Color','m');
set(r3,'Color','c');
set(r4,'Color','r');
set(r5,'Color','g');
set(r6,'Color','b');
set(r7,'Color','k');
set(r8,'Color','cyan');
%set(r2,'Color','m');
title('2-D Isomap model for the 2000 samples of the MNIST training set using tangent-distance');
xlabel('X');
ylabel('Y');
hleg1 = legend('1','2','3','4','5','6','7','8','9');
%fil = sprintf('all_tan_%d.jpg',i);
%saveas(h,fil);
hold off;

% for pointing images on the 2D plot
h = figure;
hold on;
p = plot(Y.coords{2}(1,data1),Y.coords{2}(2,data1),'o');
q = plot(Y.coords{2}(1,data7),Y.coords{2}(2,data7),'+');

bar(Y,data,data1,data7,1,7); %point the images on current plot

set(p,'Color','red');
set(q,'Color','black');
%colormap('gray');
%image(img,'XData',[2,500],'YData',[2,2000]);
title('2-D Isomap model for the 2000 samples of the MNIST training set using tangent-distance');
xlabel('X dimension');
ylabel('Y dimension');
hleg1 = legend('1','7');
hold off;


h = figure;
hold on;
p = plot(Y.coords{2}(1,data4),Y.coords{2}(2,data4),'o');
q = plot(Y.coords{2}(1,data9),Y.coords{2}(2,data9),'+');

bar(Y,data,data4,data9,4,9);

set(p,'Color','red');
set(q,'Color','black');
%colormap('gray');
%image(img,'XData',[2,500],'YData',[2,2000]);
title('2-D Isomap model for the 2000 samples of the MNIST training set using tangent-distance');
xlabel('X dimension');
ylabel('Y dimension');
hleg1 = legend('4','9');
hold off;
