Readme for the Part-A(2):
The main script is A_2.m
It assumes the data files are in ./data directory
It uses two helper functions filter1 and bar which are already included in the zip file.
It will generate all the required plots.