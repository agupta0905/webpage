function f = bar(Y,data,data4,data9,a,b)

data4_x = Y.coords{2}(1,data4);data4_y = Y.coords{2}(2,data4);
data9_x = Y.coords{2}(1,data9);data9_y = Y.coords{2}(2,data9);

xmin = min(min(data4_x),min(data9_x));
xmax = max(data4_x,max(data9_x));
ymin = min(min(data4_y),min(data9_y));
ymax = max(max(data4_y),max(data9_y));

width = (xmax-xmin)/25;
height = (xmax-xmin)/20;

flag=1;
data4_x_sorted = sort(data4_x);
data4_y_sorted = sort(data4_y);
[basex,j] = min(data4_x);
basey = data4_y(j);


for k = 1:30
    
    if (flag==1)
        vec = data(:,data4(j));
        img = zeros(28,28);
        for i = 0:27
            img(28-i,:) = vec(i*28+1:(i+1)*28);
        end
        colormap('gray');
        image(img,'XData',[data4_x(j),data4_x(j)+width],'YData',[data4_y(j),data4_y(j)+height]);
        prevx = data4_x(j);
        prevy = data4_y(j);
        flag=0;
    end
    for m = 1:size(data4_x_sorted,2)
        if ((data4_x_sorted(m) - basex) >=width)
            j=find(data4_x==data4_x_sorted(m));
            flag = 1;
            basex = data4_x_sorted(m);
            basey = data4_y_sorted(m);
            break;
        end
%         if((max(basey , data4_y_sorted(m)) - min( basey , data4_y_sorted(m))) >= 200)
%             j=find(data4_y==data4_y_sorted(m));
%             flag = 1;
%             basex = data4_x_sorted(m);
%             basey = data4_y_sorted(m);
%             break;
%          end
     end
end
    
 

flag=1;
data9_x_sorted = sort(data9_x);
data9_y_sorted = sort(data9_y);
[basex,j] = min(data9_x);
basey = data9_y(j);

for k = 1:30
    
    if (flag==1)
        vec = data(:,data9(j));
        img = zeros(28,28);
        for i = 0:27
            img(28-i,:) = vec(i*28+1:(i+1)*28);
        end
        colormap('gray');
        image(img,'XData',[data9_x(j),data9_x(j)+width],'YData',[data9_y(j),data9_y(j)+height]);
        prevx = data9_x(j);
        prevy = data9_y(j);
        flag=0;
    end
    for m = 1:size(data9_x_sorted,2)
        if ((data9_x_sorted(m) - basex) >=width)
            j=find(data9_x==data9_x_sorted(m));
            flag = 1;
            basex = data9_x_sorted(m);
            basey = data9_y_sorted(m);
            break;
        end
%         if((max(basey , data4_y_sorted(m)) - min( basey , data4_y_sorted(m))) >= 200)
%             j=find(data4_y==data4_y_sorted(m));
%             flag = 1;
%             basex = data4_x_sorted(m);
%             basey = data4_y_sorted(m);
%             break;
%          end
     end
 end





return;

