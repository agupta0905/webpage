For compilation
gcc ashug_hw1A.c
gcc ashug_hw1B.c
gcc ashug_hw1c.c

for running
./a.out<environ.txt
