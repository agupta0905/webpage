/*Program as in the ordinary vacuumWorld robot has a knowledge of its grid square (state) and
also has a memory (squares visited earlier and their values etc).It can see the four neighbouring squares.*/
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
struct node
{
    float value;
    int a[4];
};
typedef struct node node;
float perf(node map[50][50],int moves,int cx,int cy);		//Function perf returns the maximum of performances of all paths possible with
void main()							//initial point cx,cy and total moves ="moves"
{
	char tmp[30];
	scanf("%s",tmp);
	int gridr,gridc,rm,index,tmoves,n=5;			//gridr=no. of rows , gridc=no. of coloumns
	int i,j,moves,cx,cy;					//cx=x coordinate of BOT, cy=y co-ordinate of BOT
	node map[50][50];					//Map is a matrix stored in memory of bot such that
	char move;						//Map[i][j].value=dirt value at [i][j] if its value is known to BOT .
	scanf("%d",&gridr);					//Also Map[i][j].a[0]=1 indicates UP movement is possible from position i,j
	scanf("%d",&gridc);					//similarly a[1]->Right movement,a[2]->D,a[3]->L
	float floor[gridr][gridc],performance=0.0,pu=-1.0,pr=-1.0,pd=-1.0,pl=-1.0;
	scanf("%s",tmp);
	srand(time(NULL));
	for(i=0;i<gridr;i++)					//input's the grid from environ.txt to floor
	{
		for(j=0;j<gridc;j++)
		{
			scanf("%f",&floor[i][j]);
		}
	}
	scanf("%s",tmp);
	scanf("%d",&moves);
	scanf("%s",tmp);
	scanf("%d",&cx);					 //cx=x co-ordinate of BOT		
	--cx;
	scanf("%d",&cy);					//cy=y co coordinate of BOT
	--cy;
	printf("\n");
    map[0][0].value=0;						//Initialize map as the unknown value of dirt to be 0.0
    map[0][0].a[0]=0;						//and fill all the movement possible for each i,j as Bot
    map[0][0].a[1]=1;						// has knowledge of its grid square
    map[0][0].a[2]=1;											
    map[0][0].a[3]=0;
    map[gridr-1][0].value=0;
    map[gridr-1][0].a[0]=1;
    map[gridr-1][0].a[1]=1;
    map[gridr-1][0].a[2]=0;
    map[gridr-1][0].a[3]=0;
    map[0][gridc-1].value=0;
    map[0][gridc-1].a[0]=0;
    map[0][gridc-1].a[1]=0;
    map[0][gridc-1].a[2]=1;
    map[0][gridc-1].a[3]=1;
    map[gridr-1][gridc-1].value=0;
    map[gridr-1][gridc-1].a[0]=1;
    map[gridr-1][gridc-1].a[1]=0;
    map[gridr-1][gridc-1].a[2]=0;
    map[gridr-1][gridc-1].a[3]=1;
    for(i=1;i<gridc-1;i++)
    {
        map[0][i].value=0;
        map[0][i].a[0]=0;
        map[0][i].a[1]=1;
        map[0][i].a[2]=1;
        map[0][i].a[3]=1;
    }
    for(i=1;i<gridc-1;i++)
    {
        map[gridr-1][i].value=0;
        map[gridr-1][i].a[0]=1;
        map[gridr-1][i].a[1]=1;
        map[gridr-1][i].a[2]=0;
        map[gridr-1][i].a[3]=1;
    }
    for(i=1;i<gridr-1;i++)
    {
        map[i][0].value=0;
        map[i][0].a[0]=1;
        map[i][0].a[1]=1;
        map[i][0].a[2]=1;
        map[i][0].a[3]=0;
    }
    for(i=1;i<gridc-1;i++)
    {
        map[i][gridc-1].value=0;
        map[i][gridc-1].a[0]=1;
        map[i][gridc-1].a[1]=0;
        map[i][gridc-1].a[2]=1;
        map[i][gridc-1].a[3]=1;
    }
    for(i=1;i<gridr-1;i++)
    {
        for(j=1;j<gridc-1;j++)
        {
                map[i][j].value=0;
                map[i][j].a[0]=1;
                map[i][j].a[1]=1;
                map[i][j].a[2]=1;
                map[i][j].a[3]=1;
        }
    }
    for(i=0;i<moves;i++)
    {
	pu=-1.0;
	pr=-1.0;
	pd=-1.0;
	pl=-1.0;
        map[cx][cy].value=floor[cx][cy];			//update the memory map with sensory data			
        if(map[cx][cy].a[0]!=0)
        {
            map[cx-1][cy].value=floor[cx-1][cy];
        }
        if(map[cx][cy].a[1]!=0)
        {
            map[cx][cy+1].value=floor[cx][cy+1];
        }
        if(map[cx][cy].a[2]!=0)
        {
            map[cx+1][cy].value=floor[cx+1][cy];
        }
        if(map[cx][cy].a[3]!=0)
        {
            map[cx][cy-1].value=floor[cx][cy-1];
        }
        if(map[cx][cy].value!=0.0)				//if the square at the position of bot is dirty
        {
            move='S';
            performance=performance+map[cx][cy].value;
            floor[cx][cy]=0.0;
            map[cx][cy].value=0.0;
        }
        else							//if the square at the position of bot is clean
        {
	   // printf("%d %d \n",i,moves);
		
	    if(moves-1-i>3)
	    {
		tmoves=3;
	    }
	    else
	    {
		tmoves=moves-1-i;
	    }
            if(map[cx][cy].a[0]!=0)				//if U movement is possible
            {
		
		pu=perf(map,tmoves,cx-1,cy);			//pu = max performance of all paths possible of length (tmap+1) from cx,cy
		pu=pu+map[cx-1][cy].value/1000;			//where first move is taken to be movement to 'U' square
		//printf("sdsd");
	    }
	    if(map[cx][cy].a[1]!=0)				//if R movement is possible
	    {
		pr=perf(map,tmoves,cx,cy+1);			//pr = max performance of all paths possible of length (tmap+1) from cx,cy
		pr=pr+map[cx][cy+1].value/1000;			//where first move is taken to be movement to 'R' square
	    }
	    if(map[cx][cy].a[2]!=0)				//similarly as above
	    {
		pd=perf(map,tmoves,cx+1,cy);
		pd=pd+map[cx+1][cy].value/1000;			//this step distinguishes pu , pr ,pd ,pl if any of them are equal
	    }							//if equal we look at the dirt value of the next square. For example
	    if(map[cx][cy].a[3]!=0)				//if pu=pr and (Dirtvalue atU >Dirtvalue at R) then by this step pu>pr.
	    {
		pl=perf(map,tmoves,cx,cy-1);
		pl=pl+map[cx][cy-1].value/1000;
	    }
	    if(pu>pr&&pu>pd&&pu>pl)
	    {
		move='U';
		cx--;
	    }
	    else if(pd>pu&&pd>pr&&pd>pl)
            {
                move='D';
                cx++;
            }
	    else if(pl>pu&&pl>pr&&pl>pd)
            {
                move='L';
                cy--;
            }
	    else if(pr>pu&&pr>pd&&pr>pl)
            {
                move='R';
                cy++;
            }
	    else if(pu==pd&&pu>pr&&pu>pl)
	    {
	    	rm=rand()%2;
		if(rm==0)
		{	
			move='U';
			cx--;
		}
		else
		{
			move='D';
			cx++;
		}
		
	    }
	    else if(pu==pl&&pu>pr&&pu>pd)
            {
            	rm=rand()%2;
                if(rm==0)
                {
                	move='U';
                        cx--;
                }
                else
                {
                        move='L';
                        cy--;
                }
            }
	    else if(pu==pr&&pu>pd&&pu>pl)
            {
                rm=rand()%2;
                if(rm==0)
                {
                	move='U';
                        cx--;
                }
                else
                {
                        move='R';
                        cy++;
                }
            }
	    else if(pl==pd&&pl>pu&&pl>pr)
            {
                rm=rand()%2;
                if(rm==0)
                {
                	move='L';
                        cy--;
                }
                else
                {
                        move='D';
                        cx++;
                }
            }
	    else if(pr==pd&&pr>pu&&pr>pl)
            {
            	rm=rand()%2;
                if(rm==0)
                {
                        move='R';
                        cy++;
                }
                else
                {
                        move='D';
                        cx++;
                }
            }
	    else if(pl==pr&&pl>pd&&pl>pu)
            {
            	rm=rand()%2;
                if(rm==0)
                {
                	move='L';
                        cy--;
                }
                else
                {
                        move='R';
                        cy++;
                }
            }
	    else if(pu==pd&&pu==pl&&pu>pr)				
	    {
		rm=rand()%3;
		if(rm==0)
		{
			move='U';
			cx--;
		}
		else if(rm==1)
		{
			move='D';
			cx++;
		}
		else
		{
			move='L';
			cy--;
		}
	   }
	   else if(pu==pr&&pu==pl&&pu>pd)
           {
                rm=rand()%3;
                if(rm==0)
                {
                        move='U';
                        cx--;
                }
                else if(rm==1)
                {
                        move='R';
                        cy++;
                }
                else
                {
                        move='L';
                        cy--;
                }
           }
	   else if(pu==pd&&pu==pr&&pu>pl)
           {
           	rm=rand()%3;
                if(rm==0)
                {
                	move='U';
                        cx--;
                }
                else if(rm==1)
                {
                        move='D';
                        cx++;
                }
                else
                {
                        move='R';
                        cy++;
                }
           }
	   else if(pr==pd&&pr==pl&&pr>pu)
           {
                rm=rand()%3;
                if(rm==0)
                {
                        move='R';
                        cy++;
                }
                else if(rm==1)
                {
                        move='D';
                        cx++;
                }
                else
                {
                        move='L';
                        cy--;
                }
           }
	   else
	   {
		rm=rand()%4;
		if(rm==0)
		{
			move='U';
			cx--;
		}
		else if(rm==1)
		{
			move='D';
			cx++;
		}
		else if(rm==2)
		{
			move='L';
			cy--;
		}
		else 
		{
			move='R';
			cy++;
		}
	   }
    	}
	printf("%c %.1f \n",move,performance);			//print the grid after n moves
	if((i+1)%n==0)
	{
		printf("\n");
		int k,l;
		for(k=0;k<gridr;k++)
        	{
        	        for(l=0;l<gridc;l++)
        	        {
        	                if(k==cx&&l==cy)
        	                {
        	                        printf("[%.1f]  ",floor[k][l]);
        	                }
        	                else
        	                {
        	                        printf("%.1f  ",floor[k][l]);
        	                }
        	        }
                	printf("\n");
        	}
	printf("\n\n");
	}
    }
}
    
float perf(node map[50][50],int moves,int cx ,int cy)		//perf function
{
        float max=-1.0,p=0.0,tmp;
	int i,j;
	node tmap[50][50];
	for(i=0;i<50;i++)
	{
		for(j=0;j<50;j++)
		{
			tmap[i][j]=map[i][j];			//tmap is the copy of map
		}
	}
        if(moves==0)						//base case max performance in 0 moves is 0
        {
            return 0.0;
        }
        else
        {
            if(tmap[cx][cy].value!=0.0)				//max performance of all paths of no . of moves="moves"
            {							//with first move =Suck
		moves--;					//ans=p+max{perf of Up square moves-2,perf of R sq. moves-2,perf D sq. moves-2, perf L sq. moves-2}
                p=tmap[cx][cy].value;														
                tmap[cx][cy].value=0.0;
		if(moves==0)
		{
			return p;
		}
		else{
		if(tmap[cx][cy].a[0]!=0)
            	{
            	    max=perf(tmap,moves-1,cx-1,cy);
            	}
            	if(tmap[cx][cy].a[1]!=0)
            	{
                	tmp=perf(tmap,moves-1,cx,cy+1);
                	if(tmp>max)
                	{
                	    max=tmp;
                	}
            	}
            	if(tmap[cx][cy].a[2]!=0)
            	{
                	tmp=perf(tmap,moves-1,cx+1,cy);
                	if(tmp>max)
                	{
                	    max=tmp;
                	}
            	}
            	if(tmap[cx][cy].a[3]!=0)
            	{
                	tmp=perf(tmap,moves-1,cx,cy-1);
                	if(tmp>max)
                	{
                	    max=tmp;
                	}
            	}
		return p+max;
	}	
            }
	    else						//ans=max{perf of Up square moves- 1,perf of R sq. moves-1,perf D sq. moves-1, perf L sq. moves-1}
	    {
           	 if(tmap[cx][cy].a[0]!=0)
           	 {
                	max=perf(tmap,moves-1,cx-1,cy);
            	 }
            	if(tmap[cx][cy].a[1]!=0)
            	{
               	 	tmp=perf(tmap,moves-1,cx,cy+1);
                	if(tmp>max)
                	{
                	    max=tmp;
                	}
            	}
            	if(tmap[cx][cy].a[2]!=0)
            	{
                	tmp=perf(tmap,moves-1,cx+1,cy);
                	if(tmp>max)
                	{
                    	max=tmp;
                	}	
            	}
            	if(tmap[cx][cy].a[3]!=0)
            	{
                	tmp=perf(tmap,moves-1,cx,cy-1);
                	if(tmp>max)
                	{
                    		max=tmp;
                	}
            	}

            	return max;
	    }
        }
}
