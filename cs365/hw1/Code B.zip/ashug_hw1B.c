/*Reflex program as in the ordinary vacuumWorld it has no memory, no state and can sense the present square and 4 neighbouring squares.
 It can sense if any of the boundary edges are walls. It uses greedy approach to decide Action*/
#include<stdio.h>
#include<time.h>
void main()
{
	char tmp[30];                                       //temparary string
	scanf("%s",tmp);
	int gridr,gridc,rm;                                 //gridr=no of rows, gridc=no of coloumns
	int i,j,moves,cx,cy,n=5;                            //cx =x coordinate, cy =y coordinate of bot ,initially inputed from environ.txt
	char move;
	scanf("%d",&gridr);
	scanf("%d",&gridc);
	float floor[gridr][gridc],performance=0.0;
	scanf("%s",tmp);
	srand(time(NULL));
	for(i=0;i<gridr;i++)                                //inputing grid from environ.txt
	{
		for(j=0;j<gridc;j++)
		{
			scanf("%f",&floor[i][j]);
		}
	}
	scanf("%s",tmp);
	scanf("%d",&moves);
	scanf("%s",tmp);
	scanf("%d",&cx);
	--cx;
	scanf("%d",&cy);
	--cy;
	printf("\n");
	for(i=0;i<moves;i++)
	{
		if(floor[cx][cy]!=0.0)                          //if square is dirty
		{
			move='S';
			performance=performance+floor[cx][cy];
			floor[cx][cy]=0.0;
		}
		else
		{
			if(gridr==1)                                //if only one row
			{
				if(gridc==1)                            //if only one cell
				{
					move='N';
				}
				else
				{
					if(cy==0)                           //Bot on first coloumn(when one row)
					{
						move='R';
						cy++;
					}
					else if(cy==gridc-1)                //Bot on Last coloumn (when one row)
					{
						move='L';
						cy--;
					}
					else                                //Bot neither on first nor on last coloumn(when 1 row)
					{
						rm=rand()%2;
						if(floor[cx][cy-1]>floor[cx][cy+1]) //Dirt on Left>Dirt on Right
						{
							move='L';
							cy--;
						}
						else if(floor[cx][cy-1]<floor[cx][cy+1])//Dirt on Right > Dirt on Left
						{
							move='R';
							cy++;
						}
						else                            //Dirt on right==Dirt on Left
						{
							if(rm==0)
							{
								move='L';
								cy--;
							}
							else
							{
								move='R';
								cy++;
							}
						}
					}
				}
			}
			else if(gridc==1)                           //similarly when only one coloumn diff cases
			{
				if(cx==0)
                {
                    move='D';
                    cx++;
                }
                else if(cx==gridr-1)
                {
                    move='U';
                    cx--;
                }
                else
                {
                    rm=rand()%2;
					if(floor[cx+1][cy]>floor[cx-1][cy])
					{
						move='D';
						cx++;
					}
					else if(floor[cx+1][cy]<floor[cx-1][cy])
					{
						move='U';
						cx--;
					}
					else
					{
                        if(rm==0)
                        {
                            move='D';
                            cx++;
                        }
                        else
                        {
                            move='U';
                            cx--;
                        }
					}
                }
            }
			else                                        //atleast 2 rows and 2 coloumns
			{
				rm=rand()%2;
				if(cx==0&&cy==0)                        //Bot on TopLeft corner
				{
					if(floor[cx][cy+1]>floor[cx+1][cy]) //Greedy check
					{
						move='R';
						cy++;
					}
					else if(floor[cx][cy+1]<floor[cx+1][cy])
					{
						move='D';
						cx++;
					}
					else
					{
						if(rm==0)
						{
							move='R';
							cy++;
						}
						else
						{
							move='D';
							cx++;
						}
					}
				}
				else if(cx==0&&cy==gridc-1)             //BOt on Top right corner
				{
					if(floor[cx][cy-1]>floor[cx+1][cy]) //greedy check
					{
						move='L';
						cy--;
					}
					else if(floor[cx][cy-1]<floor[cx+1][cy])
					{
						move='D';
						cx++;
					}
					else
					{
                        if(rm==0)
                        {
                            move='L';
                            cy--;
                        }
                        else
                        {
                            move='D';
                            cx++;
                        }
					}
				}
				else if(cx==gridr-1&&cy==0)             //Bottom Left corner
				{
					if(floor[cx-1][cy]>floor[cx][cy+1]) //greedy check
                    {
                        move='U';
                        cx--;
                    }
                    else if(floor[cx-1][cy]<floor[cx][cy+1])
                    {
                        move='R';
                        cy++;
                    }
					else
					{
                        if(rm==0)
                        {
                            move='R';
                            cy++;
                        }
                        else
                        {
                            move='U';
                            cx--;
                        }
					}
				}
				else if(cx==gridr-1&&cy==gridc-1)       //bottom right corner
				{
					if(floor[cx][cy-1]>floor[cx-1][cy]) //greedy check
                    {
                        move='L';
                        cy--;
                    }
                    else if(floor[cx][cy-1]<floor[cx-1][cy])
                    {
                        move='U';
                        cx--;
                    }
					else
					{
                        if(rm==0)
                        {
                            move='L';
                            cy--;
                        }
                        else
                        {
                            move='U';
                            cx--;
                        }
					}
				}
				else if(cx==0)                          //Top row except corners
				{                                       //greedy check

					if((floor[cx][cy-1]>floor[cx][cy+1])&&(floor[cx][cy-1]>floor[cx+1][cy]))    //L>{R,U,D}
					{
						move='L';
						cy--;
					}
					else if((floor[cx][cy+1]>floor[cx][cy-1])&&(floor[cx][cy+1]>floor[cx+1][cy]))
					{
						move='R';
						cy++;
					}
					else if((floor[cx+1][cy]>floor[cx][cy+1])&&(floor[cx+1][cy]>floor[cx][cy-1]))
					{
						move='D';
						cx++;
					}
					else if((floor[cx][cy-1]==floor[cx][cy+1])&&(floor[cx][cy-1]>floor[cx+1][cy]))
					{
						rm=rand()%2;
						if(rm==0)
						{
							move='L';
							cy--;
						}
						else
						{
							move='R';
							cy++;
						}
					}
					else if((floor[cx][cy-1]==floor[cx+1][cy])&&(floor[cx][cy-1]>floor[cx][cy+1]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='L';
                            cy--;
                        }
                        else
                        {
                            move='D';
                            cx++;
                        }
                    }
					else if((floor[cx][cy+1]==floor[cx+1][cy])&&(floor[cx][cy+1]>floor[cx][cy-1]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='D';
                            cx++;
                        }
                        else
                        {
                            move='R';
                            cy++;
                        }
                    }
					else
					{
						rm=rand()%3;
						if(rm==0)
						{
							move='L';
							cy--;
						}
						else if(rm==1)
						{
							move='R';
							cy++;
						}
						else
						{
							move='D';
							cx++;
						}
					}
				}
				else if(cy==0)	                        //First coloumn except corners
				{                                       //greedy check
					if((floor[cx-1][cy]>floor[cx][cy+1])&&(floor[cx-1][cy]>floor[cx+1][cy]))
                    {
                        move='U';
                        cx--;
                    }
                    else if((floor[cx][cy+1]>floor[cx-1][cy])&&(floor[cx][cy+1]>floor[cx+1][cy]))
                    {
                        move='R';
                        cy++;
                    }
                    else if((floor[cx+1][cy]>floor[cx][cy+1])&&(floor[cx+1][cy]>floor[cx-1][cy]))
                    {
                        move='D';
                        cx++;
                    }
                    else if((floor[cx-1][cy]==floor[cx][cy+1])&&(floor[cx-1][cy]>floor[cx+1][cy]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else
                        {
                            move='R';
                            cy++;
                        }
                    }
                    else if((floor[cx-1][cy]==floor[cx+1][cy])&&(floor[cx-1][cy]>floor[cx][cy+1]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else
                        {
                            move='D';
                            cx++;
                        }
                    }
                    else if((floor[cx][cy+1]==floor[cx+1][cy])&&(floor[cx][cy+1]>floor[cx-1][cy]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='D';
                            cx++;
                        }
                        else
                        {
                            move='R';
                            cy++;
                        }
                    }
					else
					{
						rm=rand()%3;
                        if(rm==0)
                        {
                            move='D';
                            cx++;
                        }
                        else if(rm==1)
                        {
                            move='U';
                            cx--;
                        }
                        else
                        {
                            move='R';
                            cy++;
                        }
					}
				}
				else if(cx==gridr-1)	                //last row except corners
				{                                       //greedy check
					if((floor[cx-1][cy]>floor[cx][cy-1])&&(floor[cx-1][cy]>floor[cx][cy+1]))
                    {
                        move='U';
                        cx--;
                    }
                    else if((floor[cx][cy+1]>floor[cx-1][cy])&&(floor[cx][cy+1]>floor[cx][cy-1]))
                    {
                        move='R';
                        cy++;
                    }
                    else if((floor[cx][cy-1]>floor[cx][cy+1])&&(floor[cx][cy-1]>floor[cx-1][cy]))
                    {
                        move='L';
                        cy--;
                    }
                    else if((floor[cx-1][cy]==floor[cx][cy+1])&&(floor[cx-1][cy]>floor[cx][cy-1]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else
                        {
                            move='R';
                            cy++;
                        }
                    }
					else if((floor[cx-1][cy]==floor[cx][cy-1])&&(floor[cx-1][cy]>floor[cx][cy+1]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else
                        {
                            move='L';
                            cy--;
                        }
                    }
                    else if((floor[cx][cy+1]==floor[cx][cy-1])&&(floor[cx][cy+1]>floor[cx-1][cy]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='L';
                            cy--;
                        }
                        else
                        {
                            move='R';
                            cy++;
                        }
                    }
					else
					{
						rm=rand()%3;
						if(rm==0)
						{
							move='R';
							cy++;
						}
						else if(rm==1)
						{
							move='L';
							cy--;
						}
						else
						{
							move='U';
							cx--;
						}
					}
				}
				else if(cy==gridc-1)                    //Last coloumn
				{                                       //greedy check
					if((floor[cx-1][cy]>floor[cx][cy-1])&&(floor[cx-1][cy]>floor[cx+1][cy]))
                    {
                        move='U';
                        cx--;
                    }
                    else if((floor[cx][cy-1]>floor[cx-1][cy])&&(floor[cx][cy-1]>floor[cx+1][cy]))
                    {
                        move='L';
                        cy--;
                    }
                    else if((floor[cx+1][cy]>floor[cx][cy-1])&&(floor[cx+1][cy]>floor[cx-1][cy]))
                    {
                        move='D';
                        cx++;
                    }
                    else if((floor[cx-1][cy]==floor[cx][cy-1])&&(floor[cx-1][cy]>floor[cx+1][cy]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else
                        {
                            move='L';
                            cy--;
                        }
                    }
                    else if((floor[cx-1][cy]==floor[cx+1][cy])&&(floor[cx-1][cy]>floor[cx][cy-1]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else
                        {
                            move='D';
                            cx++;
                        }
                                        }
					else if((floor[cx][cy-1]==floor[cx+1][cy])&&(floor[cx][cy-1]>floor[cx-1][cy]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='D';
                            cx++;
                        }
                        else
                        {
                            move='L';
                            cy--;
                        }
                    }
					else
					{
						rm=rand()%3;
						if(rm==0)
						{
							move='D';
							cx++;
						}
						else if(rm==1)
						{
							move='U';
							cx--;
						}
						else
						{
							move='L';
							cy--;
						}
					}
				}
				else                                    //bot's square has no booundary edge
				{                                       //greedy check
					if((floor[cx-1][cy]>floor[cx+1][cy])&&(floor[cx-1][cy]>floor[cx][cy-1])&&(floor[cx-1][cy]>floor[cx][cy+1]))
					{
						move='U';
						cx--;
					}
					else if((floor[cx+1][cy]>floor[cx-1][cy])&&(floor[cx+1][cy]>floor[cx][cy-1])&&(floor[cx+1][cy]>floor[cx][cy+1]))
                                        {
                                                move='D';
                                                cx++;
                                        }
					else if((floor[cx][cy-1]>floor[cx+1][cy])&&(floor[cx][cy-1]>floor[cx-1][cy])&&(floor[cx][cy-1]>floor[cx][cy+1]))
                                        {
                                                move='L';
                                                cy--;
                                        }
					else if((floor[cx][cy+1]>floor[cx+1][cy])&&(floor[cx][cy+1]>floor[cx][cy-1])&&(floor[cx][cy+1]>floor[cx-1][cy]))
                                        {
                                                move='R';
                                                cy++;
                                        }
					else if((floor[cx-1][cy]==floor[cx+1][cy])&&(floor[cx-1][cy]>floor[cx][cy-1])&&(floor[cx-1][cy]>floor[cx][cy+1]))
					{
						rm=rand()%2;
						if(rm==0)
						{
							move='U';
							cx--;
						}
						else
						{
							move='D';
							cx++;
						}
					}
					else if((floor[cx-1][cy]==floor[cx][cy-1])&&(floor[cx-1][cy]>floor[cx+1][cy])&&(floor[cx-1][cy]>floor[cx][cy+1]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else
                        {
                            move='L';
                            cy--;
                        }
                    }
					else if((floor[cx-1][cy]==floor[cx][cy+1])&&(floor[cx-1][cy]>floor[cx][cy-1])&&(floor[cx-1][cy]>floor[cx+1][cy]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else
                        {

                            move='R';
                            cy++;
                        }
                    }
					else if((floor[cx+1][cy]==floor[cx][cy-1])&&(floor[cx+1][cy]>floor[cx][cy+1])&&(floor[cx+1][cy]>floor[cx-1][cy]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='L';
                            cy--;
                            }
                        else
                        {
                            move='D';
                            cx++;
                        }
                    }
					else if((floor[cx+1][cy]==floor[cx][cy+1])&&(floor[cx+1][cy]>floor[cx][cy-1])&&(floor[cx+1][cy]>floor[cx-1][cy]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='R';
                            cy++;
                        }
                        else
                        {
                            move='D';
                            cx++;
                        }
                    }
					else if((floor[cx][cy-1]==floor[cx][cy+1])&&(floor[cx][cy-1]>floor[cx+1][cy])&&(floor[cx][cy-1]>floor[cx-1][cy]))
                    {
                        rm=rand()%2;
                        if(rm==0)
                        {
                            move='L';
                            cy--;
                        }
                        else
                        {
                            move='R';
                            cy++;
                        }
                    }
					else if((floor[cx-1][cy]==floor[cx+1][cy])&&(floor[cx-1][cy]==floor[cx][cy-1])&&(floor[cx-1][cy]>floor[cx][cy+1]))
					{
						rm=rand()%3;
						if(rm==0)
						{
							move='U';
							cx--;
						}
						else if(rm==1)
						{
							move='D';
							cx++;
						}
						else
						{
							move='L';
							cy--;
						}
					}
					else if((floor[cx-1][cy]==floor[cx][cy-1])&&(floor[cx-1][cy]==floor[cx][cy+1])&&(floor[cx-1][cy]>floor[cx+1][cy]))
                    {
                        rm=rand()%3;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else if(rm==1)
                        {
                            move='R';
                            cy++;
                        }
                        else
                        {
                            move='L';
                            cy--;
                        }
                    }
					else if((floor[cx-1][cy]==floor[cx+1][cy])&&(floor[cx-1][cy]==floor[cx][cy+1])&&(floor[cx-1][cy]>floor[cx][cy-1]))
                    {
                        rm=rand()%3;
                        if(rm==0)
                        {
                            move='U';
                            cx--;
                        }
                        else if(rm==1)
                        {
                            move='D';
                            cx++;
                        }
                        else
                        {
                            move='R';
                            cy++;
                        }
                    }
					else if((floor[cx+1][cy]==floor[cx][cy-1])&&(floor[cx+1][cy]==floor[cx][cy+1])&&(floor[cx+1][cy]>floor[cx-1][cy]))
                    {
                        rm=rand()%3;
                        if(rm==0)
                        {
                            move='R';
                            cy++;
                        }
                        else if(rm==1)
                        {
                            move='D';
                            cx++;
                        }
                        else
                        {
                            move='L';
                            cy--;
                        }
                    }
					else
					{
						rm=rand()%4;
						if(rm==0)
						{
							move='U';
							cx--;
						}
						else if(rm==1)
						{
							move='D';
							cx++;
						}
						else if(rm==2)
						{
							move='L';
							cy--;
						}
						else
						{
							move='R';
							cy++;
						}
					}
				}
			}
		}
		printf("%c %.1f\n",move,performance);
		int k,l;
		if((i+1)%n==0)                                  //print grid after every N moves
		{
			for(k=0;k<gridr;k++)
			{
				for(l=0;l<gridc;l++)
				{
					if(k==cx&&l==cy)
					{
						printf("[%.1f]  ",floor[k][l]);
					}
					else
					{
						printf("%.1f  ",floor[k][l]);
					}
				}
				printf("\n");
			}
			printf("\n");
		}
	}
	printf("\n");
}


