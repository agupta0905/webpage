/*Reflex program as in the ordinary vacuumWorld - it has no memory, no state and can only sense the present square.
 It can sense the value of dirt present in and also if any of the boundary edges are walls.*/
#include<stdio.h>
#include<time.h>
void main()
{
	char tmp[30];                                            //tmp string
    scanf("%s",tmp);
	int gridr,gridc,rm,n=5;                                  //gridr=no of rows,gridc=no of coloumns, rm=random no.
	int i,j,moves,cx,cy;
	char move;
	scanf("%d",&gridr);                                      //taking input from enviorn.txt file
	scanf("%d",&gridc);
	float floor[gridr][gridc],performance=0.0;
	scanf("%s",tmp);
	srand(time(NULL));
	for(i=0;i<gridr;i++)                                     //taking grid as input from enviornment.txt
	{
		for(j=0;j<gridc;j++)
		{
			scanf("%f",&floor[i][j]);
		}
	}
	scanf("%s",tmp);
	scanf("%d",&moves);
	scanf("%s",tmp);
	scanf("%d",&cx);                                        //cx is the x co-ordinate of bot initially inputed from environ.txt
	--cx;
	scanf("%d",&cy);
	--cy;                                                   //cy is the y co-ordinate of bot initially inputed from environ.txt
	printf("\n");
	for(i=0;i<moves;i++)
	{
		if(floor[cx][cy]!=0.0)                              //if the square bot is on is dirty
		{
			move='S';
			performance=performance+floor[cx][cy];          //performance is the amount of dirt it has collected
			floor[cx][cy]=0.0;
		}
		else                                                //if the sqaure bot is on is clean
		{
			if(gridr==1)
			{
				if(gridc==1)                                //if there is only one sqaure
				{
					move='N';
				}
				else                                        //if there is only one row
				{
					if(cy==0)                               //Bot is on first coloumn (when only one row)
					{
						move='R';
						cy++;
					}
					else if(cy==gridc-1)                    //Bot on last coloumn (when only one row)
					{
						move='L';
						cy--;
					}
					else                                    //Bot is neither on 1st nor on Last coloumn (when only one row)
					{
						rm=rand()%2;
						if(rm==0)
						{
							move='L';
							cy--;
						}
						else
						{
							move='R';
							cy++;
						}
					}
				}
			}
			else if(gridc==1)                               //when only one coloumn
			{
				if(cx==0)                                   //bot in 1st row (when only 1 coloumn)
                {
                    move='D';
                    cx++;
                }
                else if(cx==gridr-1)                        //bot in last row (when only 1 coloumn)
                {
                    move='U';
                    cx--;
                }
                else                                        //bot neither on 1st nor on last row when 1 coloumn
                {
                    rm=rand()%2;
                    if(rm==0)
                    {
                        move='D';
                        cx++;
                    }
                    else
                    {
                            move='U';
                            cx--;
                    }
                }
            }
			else                                            //atleast 2 rows and 2 coloumns
			{
				rm=rand()%2;
				if(cx==0&&cy==0)                            //Bot on topmost corner
				{
					if(rm==0)
					{
						move='R';
						cy++;
					}
					else
					{
						move='D';
						cx++;
					}
				}
				else if(cx==0&&cy==gridc-1)                 //Bot on topright corner
				{
                    if(rm==0)
                    {
                        move='L';
                        cy--;
                    }
                    else
                    {
                        move='D';
                        cx++;
                    }
				}
				else if(cx==gridr-1&&cy==0)                 //Bot on bottomleft corner
				{
                    if(rm==0)
                    {
                        move='R';
                        cy++;
                    }
                    else
                    {
                        move='U';
                        cx--;
                    }
				}
				else if(cx==gridr-1&&cy==gridc-1)           //Bot on botright corner
				{
                    if(rm==0)
                    {
                        move='L';
                        cy--;
                    }
                    else
                    {
                        move='U';
                        cx--;
                    }
				}

				else if(cx==0)                              //Bot on top row (except corners)
				{
					rm=rand()%3;
					if(rm==0)
					{
						move='L';
						cy--;
					}
					else if(rm==1)
					{
						move='R';
						cy++;
					}
					else
					{
						move='D';
						cx++;
					}
				}
				else if(cy==0)                              //Bot on Leftmost coloumn(except corners)
				{
					rm=rand()%3;
                    if(rm==0)
                    {
                        move='D';
                        cx++;
                    }
                    else if(rm==1)
                    {
                        move='U';
                        cx--;
                    }
                    else
                    {
                        move='R';
                        cy++;
                    }
				}
				else if(cx==gridr-1)                        //Bot on Bottom row(except corners)
				{
					rm=rand()%3;
					if(rm==0)
					{
						move='R';
						cy++;
					}
					else if(rm==1)
					{
						move='L';
						cy--;
					}
					else
					{
						move='U';
						cx--;
					}
				}
				else if(cy==gridc-1)                       //Bot on Rightmost coloumn (except corners)
				{
					rm=rand()%3;
					if(rm==0)
					{
						move='D';
						cx++;
					}
					else if(rm==1)
					{
						move='U';
						cx--;
					}
					else
					{
						move='L';
						cy--;
					}
				}
				else                                    //Bot can go in anydirection (has no boundary edge)
				{
					rm=rand()%4;
					if(rm==0)
					{
						move='U';
						cx--;
					}
					else if(rm==1)
					{
						move='D';
						cx++;
					}
					else if(rm==2)
					{
						move='L';
						cy--;
					}
					else
					{
						move='R';
						cy++;
					}
				}
			}
		}
		printf("%c %.1f\n",move,performance);
		int k,l;
		if((i+1)%n==0)                                  //printing grid after every N steps
		{
			for(k=0;k<gridr;k++)
			{
				for(l=0;l<gridc;l++)
				{
					if(k==cx&&l==cy)
					{
						printf("[%.1f]  ",floor[k][l]);
					}
					else
					{
						printf("%.1f  ",floor[k][l]);
					}
				}
				printf("\n");
			}
			printf("\n");
		}
	}
	printf("\n");
}


